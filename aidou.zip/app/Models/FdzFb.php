<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class FdzFb extends Model
{
	
    protected $table = 'fdz_fb';
    public $timestamps = false;

}
