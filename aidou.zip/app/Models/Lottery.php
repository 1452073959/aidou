<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Lottery extends Model
{
	
    protected $table = 'lottery';
    public $timestamps = false;

}
