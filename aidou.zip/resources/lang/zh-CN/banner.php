<?php 
return [
    'labels' => [
        'Banner' => 'Banner',
    ],
    'fields' => [
        'img' => 'img',
        'url' => 'url',
    ],
    'options' => [
    ],
];
