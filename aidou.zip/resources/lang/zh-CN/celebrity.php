<?php 
return [
    'labels' => [
        'Celebrity' => 'Celebrity',
    ],
    'fields' => [
        'name' => '明星姓名',
        'avatar' => '头像',
        'backimage' => '背景图',
        'influencenum' => '影响力',
    ],
    'options' => [
    ],
];
