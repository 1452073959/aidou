<?php 
return [
    'labels' => [
        'Lottery' => 'Lottery',
    ],
    'fields' => [
        'title' => '标题',
        'type' => '1票2钻石',
        'sum' => '数量',
    ],
    'options' => [
    ],
];
